x = 1.0

for i in range(41):
    print(f"{x:.02f}")
    x -= 0.05
